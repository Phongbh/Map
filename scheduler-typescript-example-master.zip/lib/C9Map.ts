import CenterObj from './CenterObj';
var Map = require('ol/Map');
var View = require('ol/View');
var TileLayer = require('ol/layer/Tile');
var OSM = require('ol/source/OSM');

export default class C9Map {

    /** el String Element id of html */
    el: String;

    /** latlng LatLng */
    centerObj: CenterObj;

    /**
     * Constructor
     * 
     * @param el String Element id of html
     * @param latlng LatLng
     * @return void
     */
    constructor(el:String, lat: number, lng: number, zoom: number){
        this.el = el;
        this.centerObj = new CenterObj(lat, lng, zoom);
        return this.initMap();
    }

    getCenter(){
        return this.centerObj.getCenter();
    }

    setCenter(lat: number, lng: number){
        this.centerObj.setCenter(lat, lng);
    }
    
    initMap(){
        return new Map({
            layer:[
                new TileLayer({
                    source: new OSM()
                })
            ],
            target: this.el,
            view: new View({
                 center: this.centerObj.getCenter(),
                 zoom: this.centerObj.getZoom()
             })
        });
    }
}