export default class CenterObj {
    lat: number;
    lng: number;
    zoom: number;

    /**
     * Constructor
     * 
     * @param lat number latitutde
     * @param lng number longitude
     * @returns void 
     */
    constructor(lat: number, lng: number, zoom: number){
        this.lat = lat;
        this.lng = lng;
        this.zoom = zoom;
    }

    getCenter(){
        return [this.lat, this.lng];
    }

    setCenter(lat: number, lng: number){
        this.lat = lat;
        this.lng = lng;
    }

    getZoom(){
        return this.zoom;
    }

    setZoom(zoom: number){
        this.zoom = zoom;
    }
    /**
     * Export object to json
     * 
     * @param ob CenterObj object need convert
     * @returns String JSON
     */
    toJson(ob: CenterObj){
        return JSON.stringify(ob);
    }
}