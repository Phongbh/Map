import C9Map from '../lib/C9Map';

$(function() {
  //let el: JQuery = $('#map');

  let map = new C9Map("map", 108.2261, 16.0541, 4);
  
  
});


      


