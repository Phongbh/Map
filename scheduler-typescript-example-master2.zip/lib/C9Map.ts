import CenterObj from './CenterObj';
// // var Map = require('ol/Map');
// // var View = require('ol/View');
// // var TileLayer = require('ol/layer/Tile');
// // var OSM = require('ol/source/OSM');
// //var ol1 = require('ol');
// import * as ol1 from 'openlayers';

// var Map = ol1.Map;

// var View = ol1.View;
// var TileLayer = ol1.layer.Tile;

// var OSM = ol1.source.OSM;
// var MapOptions = {};

import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import OSM from "ol/source/OSM";
import fromLonLat from "ol/Proj"
import XYZ from "ol/source/XYZ";


export default class C9Map {

    

    /** el String Element id of html */
    el: HTMLElement;

    /** latlng LatLng */
    centerObj: CenterObj;

    /**
     * Constructor
     * 
     * @param el String Element id of html
     * @param latlng LatLng
     * @return void
     */
    constructor(el:HTMLElement, lat: number, lng: number, zoom: number){
        this.el = el;
        this.centerObj = new CenterObj(lat, lng, zoom);
        //return this.initMap();
    }

    getCenter(){
        return this.centerObj.getCenter();
    }

    setCenter(lat: number, lng: number){
        this.centerObj.setCenter(lat, lng);
    }
    
    initMap(){

        var MapOptions = {
            layer:[
                new TileLayer({
                    preload:4,
                    source: new OSM(),
                }),
            ],
            target: this.el,
            view: new View({
                 center:  [100,100],
                 zoom: 6,
             })
        };
        
        return new Map(MapOptions);
    }
}